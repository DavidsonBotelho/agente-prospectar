"""DeepAgents CLI - Interactive AI coding assistant."""

from deepagents_cli.main import cli_main

__all__ = ["cli_main"]
